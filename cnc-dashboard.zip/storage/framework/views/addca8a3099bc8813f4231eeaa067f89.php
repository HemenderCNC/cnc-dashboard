<!DOCTYPE html>
<html>
<head>
    <title>Password Reset OTP</title>
</head>
<body>
    <p>Dear User,</p>
    <p>Your OTP for password reset is: <strong><?php echo e($otp); ?></strong></p>
    <p>This OTP will expire in 15 minutes.</p>
    <p>Thank you,</p>
    <p><?php echo e(config('app.name')); ?> Team</p>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\cnc-dashboard\resources\views/emails/otp.blade.php ENDPATH**/ ?>